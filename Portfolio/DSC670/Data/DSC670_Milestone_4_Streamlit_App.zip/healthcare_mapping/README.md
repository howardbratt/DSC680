# Healthcare Data Mapping Assistant

**Student Name:** Shelia Howard  
**Course:** DSC670-T301 Advanced Uses of Generative AI (2271-1)  
**Assignment:** Term Project - Milestone 4  
**Due Date:** Sunday, 11/22/2026 at 11:59 p.m. CT  
**Dataset(s):** `demo_cases.json` contains two authored synthetic examples. Live inference uses synthetic metadata entered in the form. Historical evaluation figures are from the completed Milestone 3 PDF and final Colab notebook, which document `mapping_train.csv` (192), `mapping_validation.csv` (48), `mapping_test.csv` (48), `mapping_challenge.csv` (8), and `mapping_legacy.csv` (30). Runtime does not require those CSVs.

## Assignment coverage

| Professor's request | Deliverable |
| --- | --- |
| Working Streamlit app using the project solution | `app.py` and `mapping.py`. Live inference requires the saved Milestone 3 checkpoint. |
| Source code as one or more Python files | Both Python files are included in the app ZIP. |
| Short PowerPoint with running-app screenshots | The accompanying presentation includes a narration script in speaker notes. The included screenshots show the illustrative workflow. Capture live evidence after connecting the checkpoint. |
| Optional video | The slide notes provide a script if you choose to record one. |
| Suggested private GitHub submission | Private repository and Community Cloud instructions appear below. |
| Student-requested companion notebook | The accompanying notebook documents the implementation and verifies the demo data and response checks. |

The assignment directions in the prompt were used because no separate Word document or scoring rubric was attached. The earlier OpenAI notebook is an abandoned training path. The completed Milestone 3 report and final Qwen Colab notebook define the app's model and prompt.

## 1. Run the app locally with the original model

1. Unzip the app package and open a terminal in `healthcare_mapping`. Use Python 3.11.
2. Create a virtual environment.

   ```sh
   python -m venv .venv
   ```

   In PowerShell, activate it with `.\.venv\Scripts\Activate.ps1`. If script execution is disabled, call `.\.venv\Scripts\python.exe` in place of `python`. On macOS or Linux, run `source .venv/bin/activate`.

3. Install the model dependencies. The CPU runtime is sufficient for a smoke test. A CUDA-enabled PyTorch install can be used if your machine already has a compatible GPU/runtime.

   ```sh
   python -m pip install -r requirements-model.txt
   ```

   For the two-example illustrative app only, install `requirements.txt` instead.

4. Find the approximately 2 GB Milestone 3 download named `DSC670_Full_Model_<run-id>.zip`. Extract it and place the actual model files inside `healthcare_mapping/final_model/`. Point at the directory containing `config.json`, tokenizer files and `*.safetensors`, with no extra nested ZIP or folder. The small evidence ZIP contains evaluation artifacts. The full-model ZIP contains the weights. Alternatively, set the environment variable `MAPPING_MODEL_DIR` to the extracted model directory.
5. Start Streamlit.

   ```sh
   python -m streamlit run app.py
   ```

6. Open `http://localhost:8501`. Select **Live Qwen checkpoint**. Enter synthetic metadata and select **Generate recommendation**. The first request loads the weights. Try both inputs below.

   | Field name | Datatype | Description | Optional synthetic value | Reference decision |
   | --- | --- | --- | --- | --- |
   | patientDOB | date | Patient date of birth | 1990-04-11 | date_of_birth |
   | full_name | string | Full legal name in one field | Taylor Morgan Example | REVIEW |

   These are reference decisions. Record the checkpoint's actual output if it differs. Confirm that malformed output, if observed, goes to review. Use **Hold**, **Reject**, **Revise**, or **Accept** when a target is proposed. Download the decision as JSON and confirm that the analyst decision is separate from the recommendation.
7. Capture two screenshots with **Live Qwen checkpoint** and the recommendation visible. In the deck, replace the two illustrative screenshots and update the screenshot labels and slides' speaker notes to match the actual answers. If the model differs from a reference, keep the observed result and explain it.

## 2. Set up a private Streamlit Community Cloud app

1. Make a private GitHub repository. Add `app.py`, `mapping.py`, `demo_cases.json`, `requirements.txt`, `.gitignore`, and `README.md` at its root. Add `requirements-model.txt` only for a live-model setup. GitHub is suggested by the assignment. You can run live locally and submit the Python files and screenshots directly.
2. Sign in at [Streamlit Community Cloud](https://share.streamlit.io/) with GitHub and authorize access to the private repository.
3. Select **Create app**, then select your repository, branch, and `app.py` as the entry point. Under **Advanced settings**, select Python 3.11. Deploy.
4. In this configuration Cloud runs the illustrative demo. For a live Cloud instance, the runtime must have access to your exact checkpoint and enough RAM and startup time to load it. The bundled app expects extracted files on the host. A hosted live version needs a secure model provisioning step or a separately hosted inference backend. This package verifies the local demo path and supplies a local checkpoint integration. The local live workflow is the shortest route to assignment screenshots.
5. If you share a private Cloud app, give your professor viewer access and verify that access. A private GitHub repository also requires separate access if submitted as a link.

## 3. Run the companion notebook

Place the notebook beside `app.py` and `mapping.py`. Install JupyterLab with `python -m pip install jupyterlab` and run `python -m jupyter lab`. Run all cells from top to bottom. Enable its optional live check only after completing the checkpoint setup. The submission notebook retains the executed fixture and contract checks.

## Submission check

- Include both Python files, the JSON fixtures, dependency files, and setup instructions.
- Attach the PowerPoint. Verify the screenshots and speaker notes before submitting.
- Confirm the instructor's access to any private link you include. Use the due date above.
- Disclose whether the demo used illustrative results or the original checkpoint. Keep the Milestone 3 benchmark measurements separate from these walkthroughs.

Official documentation  
[Deploy on Streamlit Community Cloud](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy)  
[Connect a private GitHub repository](https://docs.streamlit.io/deploy/streamlit-community-cloud/get-started/connect-your-github-account)  
[Share a private app](https://docs.streamlit.io/deploy/streamlit-community-cloud/share-your-app)
